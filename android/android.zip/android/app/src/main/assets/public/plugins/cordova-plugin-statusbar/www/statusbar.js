cordova.define("cordova-plugin-statusbar.statusbar", function(require, exports, module) { 

});