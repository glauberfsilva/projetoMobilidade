"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_home_home_module_ts"],{

/***/ 3949:
/*!*********************************************!*\
  !*** ./src/app/home/home-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageRoutingModule": () => (/* binding */ HomePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 7464);




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage,
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], HomePageRoutingModule);



/***/ }),

/***/ 8245:
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageModule": () => (/* binding */ HomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 7464);
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home-routing.module */ 3949);







let HomePageModule = class HomePageModule {
};
HomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _home_routing_module__WEBPACK_IMPORTED_MODULE_1__.HomePageRoutingModule,
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage]
    })
], HomePageModule);



/***/ }),

/***/ 7464:
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePage": () => (/* binding */ HomePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _C_Users_55739_Documents_PROJETOS_UberAppGb_node_modules_ngtools_webpack_src_loaders_direct_resource_js_home_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./home.page.html */ 2056);
/* harmony import */ var _home_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page.scss */ 968);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/geolocation/ngx */ 1184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _awesome_cordova_plugins_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @awesome-cordova-plugins/native-geocoder/ngx */ 8418);







let HomePage = class HomePage {
    constructor(geo, menu, nativeGeocoder) {
        this.geo = geo;
        this.menu = menu;
        this.nativeGeocoder = nativeGeocoder;
        this.zoom = 12;
        this.address = '';
        this.sourceLocation = '';
        this.sourceLocation2 = '';
        this.destinationLocation = '';
        this.destinationLocation2 = '';
        this.directionsService = new google.maps.DirectionsService();
        this.directionsRenderer = new google.maps.DirectionsRenderer();
        this.googleAutocomplete = new google.maps.places.AutocompleteService();
        this.googleAutocomplete2 = new google.maps.places.AutocompleteService();
        this.searchResults = new Array();
        this.searchResults2 = new Array();
        console.log(google);
    }
    ngAfterViewInit() {
        this.loadMapWithDirection();
        this.whereIam();
        this.esconDer = true;
    }
    whereIam() {
        this.geo.getCurrentPosition({
            timeout: 1000,
            enableHighAccuracy: true
        }).then((res) => {
            this.lat = res.coords.latitude;
            this.lng = res.coords.longitude;
            console.log(res);
            const map = new google.maps.Map(this.mapElement.nativeElement, {
                zoom: 16,
                center: { lat: this.lat, lng: this.lng },
                disableDefaultUI: true,
            });
            const svgMarker = {
                path: "M10.453 14.016l6.563-6.609-1.406-1.406-5.156 5.203-2.063-2.109-1.406 1.406zM12 2.016q2.906 0 4.945 2.039t2.039 4.945q0 1.453-0.727 3.328t-1.758 3.516-2.039 3.070-1.711 2.273l-0.75 0.797q-0.281-0.328-0.75-0.867t-1.688-2.156-2.133-3.141-1.664-3.445-0.75-3.375q0-2.906 2.039-4.945t4.945-2.039z",
                fillColor: "black",
                fillOpacity: 1,
                strokeWeight: 0,
                rotation: 0,
                scale: 2,
                anchor: new google.maps.Point(15, 30),
            };
            const infowindow = new google.maps.InfoWindow();
            new google.maps.Marker({
                position: { lat: this.lat, lng: this.lng },
                map,
                icon: svgMarker,
                title: "Localização",
            });
            this.directionsRenderer.setMap(map);
            console.log(this.lat, this.lng);
        }).catch((e) => {
            console.log(e);
        });
        let options = {
            useLocale: true,
            maxResults: 5
        };
        this.nativeGeocoder.reverseGeocode(this.lat, this.lng, options)
            .then((result) => {
            console.log(result);
            this.localizacaoUser = result[0];
            console.log('teste123' + this.localizacaoUser.contryName);
        }).catch((error) => console.log(error));
    }
    loadMapWithDirection() {
        /*const map = new google.maps.Map(this.mapElement.nativeElement,
          {
            zoom: 14,
            center: { lat: -17.5407744, lng: -39.7685154 },
          }
        );*/
        //this.directionsRenderer.setMap(map);
    }
    calculateAndDisplayRoute() {
        this.directionsService.route({
            origin: {
                query: this.sourceLocation || this.sourceLocation2,
            },
            destination: {
                query: this.destinationLocation || this.destinationLocation2,
            },
            travelMode: google.maps.TravelMode.DRIVING,
        }, (response, status) => {
            if (status === 'OK') {
                this.directionsRenderer.setDirections(response);
                this.esconDer = false;
                console.log(this.directionsRenderer);
            }
            else {
                window.alert("Directions request failed due to " + status);
                this.esconDer = false;
            }
        });
    }
    searchChanged() {
        if (!this.sourceLocation.trim().length)
            return;
        this.googleAutocomplete.getPlacePredictions({ input: this.sourceLocation }, predictions => {
            this.searchResults = predictions;
        });
    }
    searchChanged2() {
        if (!this.destinationLocation.trim().length)
            return;
        this.googleAutocomplete2.getPlacePredictions({ input: this.destinationLocation }, predictions => {
            this.searchResults2 = predictions;
        });
    }
    calcRoute(item) {
        const resEnd = item.description;
        console.log(item.description);
        this.sourceLocation2 = item.description;
        this.sourceLocation = '';
    }
    calcRoute2(item2) {
        const resEnd = item2.description;
        console.log(item2.description);
        this.destinationLocation2 = item2.description;
        this.destinationLocation = '';
    }
    openFirst() {
        this.menu.enable(true, 'first');
        this.menu.open('first');
    }
    openEnd() {
        this.menu.open('end');
    }
    openCustom() {
        this.menu.enable(true, 'custom');
        this.menu.open('custom');
    }
};
HomePage.ctorParameters = () => [
    { type: _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_2__.Geolocation },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.MenuController },
    { type: _awesome_cordova_plugins_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_3__.NativeGeocoder }
];
HomePage.propDecorators = {
    searchElementRef: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.ViewChild, args: ['search',] }],
    esconDer: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.ViewChild, args: ['esconDer', { static: true },] }],
    mapElement: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.ViewChild, args: ['mapElement', { static: false },] }]
};
HomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-home',
        template: _C_Users_55739_Documents_PROJETOS_UberAppGb_node_modules_ngtools_webpack_src_loaders_direct_resource_js_home_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_home_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], HomePage);



/***/ }),

/***/ 2056:
/*!****************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/home/home.page.html ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n<ion-header>\n  <ion-toolbar color=\"dark\">\n    <ion-title class=\"titulohead\">Appemidias</ion-title>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button menu=\"main-menu\"></ion-menu-button>\n    </ion-buttons>\n  </ion-toolbar>\n  </ion-header>\n\n    <ion-searchbar  class=\"areaTexto1\" [(ngModel)]=\"sourceLocation\" [(ngModel)]=\"sourceLocation2\" searchIcon=\"location-outline\" (ionChange)=\"searchChanged()\" placeholder=\"Localização\" ></ion-searchbar>\n       \n    <ion-list  class=\"ion-margin-horizontal2\"  [hidden]=\"!sourceLocation\">\n     <ion-item (click)=\"calcRoute(result)\" *ngFor=\"let result of searchResults\">\n       {{result.description}}\n     </ion-item>\n   </ion-list>\n\n    <ion-searchbar class=\"custom-icon icon-edit\" searchIcon=\"navigate-outline\" [(ngModel)]=\"destinationLocation\" [(ngModel)]=\"destinationLocation2\" (ionChange)=\"searchChanged2()\" placeholder=\"Destino\" class=\"areaTexto2\"></ion-searchbar>\n  \n    <ion-list class=\"ion-margin-horizontal\"  [hidden]=\"!destinationLocation\">\n      <ion-item (click)=\"calcRoute2(result)\" *ngFor=\"let result of searchResults2\">\n        {{result.description}}\n      </ion-item>\n    </ion-list>\n\n  \n\n    <ion-footer>\n      \n   <ion-button expand=\"full\" color=\"dark\" size=\"large\" \n   class=\"botao1\" (click)=\"calculateAndDisplayRoute()\" *ngIf=\"esconDer\">Buscar Rota</ion-button>\n    \n   <div class=\"request-car ion-padding ion-text-center\" *ngIf=\"!esconDer\" >\n      <h4 class=\"ion-no-margin\">UberX</h4>\n      <span>Viagens Baratas</span>\n\n      <ion-grid class=\"ion-margin-vertical\">\n      <ion-row>\n        <ion-col size=\"4\">\n          <img class=\"imagemCars\" src=\"assets\\cartaxi.png\"/>\n          <span class=\"category\">Standart</span>\n          <span>R$12,00</span>\n        </ion-col>\n        <ion-col size=\"4\">\n          <img class=\"imagemCars\" src=\"assets\\cartaxi.png\"/>\n          <span class=\"category\">Plus</span>\n          <span>R$17,99,00</span>\n        </ion-col>\n        <ion-col size=\"4\">\n          <img class=\"imagemCars\" src=\"assets\\cartaxi.png\"/>\n          <span class=\"category\">UberX</span>\n          <span>R$35,00</span>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n\n    <ion-button routerLink=\"/inbox\" color=\"dark\" expand=\"block\" size=\"default\">QR-ROTA</ion-button>\n    \n\n    </div>\n  </ion-footer>\n\n     \n\n  <div #mapElement class=\"map\" ></div>\n  \n  ");

/***/ }),

/***/ 968:
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/***/ ((module) => {

module.exports = ".map {\n  width: 100%;\n  height: 100%;\n  z-index: 1;\n  position: absolute;\n}\n\n.ion-margin-horizontal {\n  position: absolute;\n  margin-top: 180px;\n  margin-left: 10px;\n  margin-right: 10px;\n  z-index: 100;\n}\n\n.ion-label {\n  margin-right: 150px;\n}\n\n.ion-margin-horizontal2 {\n  position: absolute;\n  margin-top: 130px;\n  margin-left: 10px;\n  margin-right: 10px;\n  z-index: 100;\n}\n\nion-searchbar {\n  --border-radius: 30px !important;\n}\n\n.titulohead {\n  margin-left: 60px;\n}\n\n.areaTexto1 {\n  z-index: 50;\n  position: fixed;\n  margin-top: 70px;\n}\n\n.ion-menu {\n  z-index: 1;\n}\n\n.areaTexto2 {\n  z-index: 2;\n  position: absolute;\n  margin-top: 120px;\n}\n\n.request-car {\n  position: absolute;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  height: 250px;\n  background-color: white;\n}\n\n.request-car .imagemCars {\n  width: 60px;\n  height: 60px;\n  border-radius: 50px;\n  display: block;\n  margin: 0 auto -15px auto;\n}\n\n.request-car span {\n  display: block;\n}\n\n.request-car ion-grid span {\n  font-size: 14px;\n  margin-bottom: 4%;\n}\n\n.request-car ion-grid span.category {\n  color: #fff;\n  background-color: #333;\n  margin-top: 0px;\n  padding: 3px 5px;\n  border-radius: bold;\n  display: inline-block;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7QUFDRjs7QUFHQTtFQUNFLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtBQUFGOztBQUdBO0VBQ0UsbUJBQUE7QUFBRjs7QUFHQTtFQUNFLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtBQUFGOztBQUdBO0VBQ0UsZ0NBQUE7QUFBRjs7QUFHRTtFQUNFLGlCQUFBO0FBQUo7O0FBSUE7RUFDRSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBREY7O0FBTUE7RUFDQSxVQUFBO0FBSEE7O0FBT0E7RUFDRSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQUpGOztBQVFBO0VBQ0Usa0JBQUE7RUFDQSxPQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7QUFMRjs7QUFTQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0EseUJBQUE7QUFQRjs7QUFXQTtFQUNFLGNBQUE7QUFURjs7QUFhRTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtBQVhKOztBQWFJO0VBQ0UsV0FBQTtFQUNBLHNCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQkFBQTtBQVhOIiwiZmlsZSI6ImhvbWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1hcHtcbiAgd2lkdGg6MTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICB6LWluZGV4OiAxO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIFxufVxuXG4uaW9uLW1hcmdpbi1ob3Jpem9udGFse1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIG1hcmdpbi10b3A6IDE4MHB4O1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICB6LWluZGV4OiAxMDA7XG59XG5cbi5pb24tbGFiZWx7XG4gIG1hcmdpbi1yaWdodDogMTUwcHg7XG59XG5cbi5pb24tbWFyZ2luLWhvcml6b250YWwye1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIG1hcmdpbi10b3A6IDEzMHB4O1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICB6LWluZGV4OiAxMDA7XG59XG5cbmlvbi1zZWFyY2hiYXJ7XG4gIC0tYm9yZGVyLXJhZGl1czogMzBweCAhaW1wb3J0YW50O1xuICB9XG4gIFxuICAudGl0dWxvaGVhZHtcbiAgICBtYXJnaW4tbGVmdDogNjBweDtcbiAgfVxuXG5cbi5hcmVhVGV4dG8xe1xuICB6LWluZGV4OiA1MDtcbiAgcG9zaXRpb246IGZpeGVkO1xuICBtYXJnaW4tdG9wOiA3MHB4O1xuICBcbn1cblxuXG4uaW9uLW1lbnV7XG56LWluZGV4OiAxO1xufVxuXG5cbi5hcmVhVGV4dG8ye1xuICB6LWluZGV4OiAyO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIG1hcmdpbi10b3A6IDEyMHB4O1xufVxuXG5cbi5yZXF1ZXN0LWNhcntcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiAwO1xuICByaWdodDogMDtcbiAgYm90dG9tOiAwO1xuICBoZWlnaHQ6IDI1MHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjU1LCAyNTUsIDI1NSk7XG5cblxuXG4uaW1hZ2VtQ2FycyB7XG4gIHdpZHRoOiA2MHB4O1xuICBoZWlnaHQ6IDYwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwcHg7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBtYXJnaW46IDAgYXV0byAtMTVweCBhdXRvO1xuXG59XG5cbnNwYW57XG4gIGRpc3BsYXk6IGJsb2NrO1xufVxuXG5pb24tZ3JpZHtcbiAgc3BhbntcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgbWFyZ2luLWJvdHRvbTogNCU7XG5cbiAgICAmLmNhdGVnb3J5IHtcbiAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogIzMzMztcbiAgICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICAgIHBhZGRpbmc6IDNweCA1cHg7XG4gICAgICBib3JkZXItcmFkaXVzOiBib2xkO1xuICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgIH1cbiAgfVxufVxufSJdfQ== */";

/***/ })

}]);
//# sourceMappingURL=src_app_home_home_module_ts.js.map